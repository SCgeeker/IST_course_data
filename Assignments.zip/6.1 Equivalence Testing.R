m1<-4.
m2<-4.1
sd1<-1.05
sd2<-1.11
n1<-60
n2<-60

eqbound_d<- 0.4 #smallest effect size of interest

#perform TOST procedure
sdpooled<-sqrt((((n1 - 1)*(sd1^2)) + (n2 - 1)*(sd2^2))/((n1+n2)-2)) #calculate sd pooled
eqbound<-eqbound_d*sdpooled #multiply eq_bound by pooled sd to get raw bound
t1<-(abs(m1-m2)+eqbound)/(sdpooled*sqrt(1/n1 + 1/n2))
p1<-pt(t1, n1+n2-2, lower=FALSE) #p-value for first t-test
t2<-(abs(m1-m2)-eqbound)/(sdpooled*sqrt(1/n1 + 1/n2))
p2<-pt(t2, n1+n2-2, lower=TRUE) #p-value for second t-test
LL<-(m1-m2)-qt(0.95, n1+n2-2)*(sdpooled*sqrt(1/n1 + 1/n2)) #calculate lower limit
UL<-(m1-m2)+qt(0.95, n1+n2-2)*(sdpooled*sqrt(1/n1 + 1/n2)) #calculate upper limit
t<-(m1-m2)/(sdpooled*sqrt(1/n1 + 1/n2)) #perform conventional t-test against H0 = 0
pttest<-2*pt(-abs(t), df=n1+n2-2) #calculate p-value for conventional t-test
ptost<-max(p1,p2) #store highest p-value of the tost procedure
results<-data.frame(ptost,LL,UL) #store results
dif<-(m1-m2) #calculate mean difference
df = data.frame(labels=c("90% CI mean","Equivalence Range"), mean=c(dif,0), lower=c(LL,-eqbound), upper = c(UL,eqbound))

#create plot
plot(NA, xlim=c(.5,2.5), ylim=c(min(LL,-eqbound)-0.5, max(UL,eqbound)+0.5), bty="l", xaxt="n", xlab="",ylab="Mean Difference")
points(df$mean[1:2], pch=19)
points(1,(m1-m2)-qnorm(0.975)*(sdpooled*sqrt(1/n1 + 1/n2)),pch=10)
points(1,(m1-m2)+qnorm(0.975)*(sdpooled*sqrt(1/n1 + 1/n2)),pch=10)
axis(1, 1:2, df$labels)
segments(1:2,df$lower[1:2],1:2,df$upper[1:2])
segments(1:1,df$upper[1:1],1:2,df$upper[1:1],lty=3)
segments(2,0,0,0,lty=2)
segments(1:1,df$lower[1:1],1:2,df$lower[1:1],lty=3)
text(2, min(LL,-eqbound)-0.2, paste("p-value",round(ptost, digits=3)), cex = .8)
text(1, min(LL,-eqbound)-0.2, paste("\np-value",round(pttest, digits=3),"\nt-value",round(t,digits=3)), cex = .8)
text(1.5, dif, paste("Mdif = ",round(dif, digits=3)), cex = .8)
title(main=paste("Mdif = ",round(dif,digits=3),", 95% CI [",round(((m1-m2)-qnorm(0.975)*(sdpooled*sqrt(1/n1 + 1/n2))),digits=3),";",round(((m1-m2)+qnorm(0.975)*(sdpooled*sqrt(1/n1 + 1/n2))),digits=3),"]",", p = ",round(pttest,digits=3), sep=""), cex.main=1)

#return results
results

#� Daniel Lakens, 2016. 
# This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. https://creativecommons.org/licenses/by-nc-sa/4.0/